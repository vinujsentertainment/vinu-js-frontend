VINU JS SECURE V18
===================

Backend
-------
1. Deploy backend/ to Render.
2. Build command: npm install
3. Start command: npm start
4. Required Render environment variables:
   DATABASE_URL = your PostgreSQL connection string
   NODE_ENV = production
   ADMOB_REWARDED_AD_UNIT = your AdMob rewarded ad unit ID

Frontend
--------
Upload frontend/index.html and icon.png to the frontend host.
It reads the wallet/history from:
https://vinu-js-backend.onrender.com

AdMob SSV
---------
Configure the AdMob rewarded ad unit's server-side verification callback to:
https://vinu-js-backend.onrender.com/api/admob/ssv

The Android app must set ServerSideVerificationOptions custom data
before showing the rewarded ad. The backend verifies Google's signature,
checks timestamp/ad-unit/reward, deduplicates transaction_id, then credits
the PostgreSQL wallet.

Important
---------
The web frontend intentionally has NO endpoint that accepts an arbitrary
reward amount. This prevents users from calling a public API to mint money.

Withdrawal
----------
/api/withdraw creates a Pending request and deducts the requested balance
atomically. It does NOT automatically send UPI money. Automatic payout
requires a properly configured payout provider/admin workflow.

Ad revenue
----------
The displayed wallet reward is your configured reward amount, not a claim
that every ad generates that exact amount of advertising revenue.
Actual ad revenue varies by network, country, demand, fill, impressions,
and policy compliance.

SSV public keys
--------------
AdMob public keys are fetched and cached for less than 24 hours because
Google rotates them. The signature content/order is preserved for
verification.
