const express = require("express");
const cors = require("cors");
const crypto = require("crypto");
const { Pool } = require("pg");

const app = express();
app.set("trust proxy", 1);
app.use(cors({ origin: true }));
app.use(express.json({ limit: "50kb" }));

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production"
    ? { rejectUnauthorized: false }
    : false
});

const PORT = process.env.PORT || 10000;
const MIN_WITHDRAWAL = 100;
const SSV_MAX_AGE_MS = 24 * 60 * 60 * 1000;
const ADMOB_SSV_AD_UNIT = process.env.ADMOB_REWARDED_AD_UNIT || "";
const ADMOB_KEYS_URL = "https://www.gstatic.com/admob/reward/verifying-keys.json";

let keyCache = { keys: new Map(), fetchedAt: 0 };

async function db() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      balance INTEGER NOT NULL DEFAULT 0 CHECK(balance >= 0),
      total_earned INTEGER NOT NULL DEFAULT 0 CHECK(total_earned >= 0),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS ad_rewards (
      transaction_id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id),
      reward_amount INTEGER NOT NULL CHECK(reward_amount > 0),
      reward_item TEXT,
      ad_unit TEXT,
      ad_network TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS transactions (
      id BIGSERIAL PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id),
      amount INTEGER NOT NULL,
      type TEXT NOT NULL,
      description TEXT NOT NULL,
      reference_id TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS withdrawals (
      id BIGSERIAL PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id),
      amount INTEGER NOT NULL CHECK(amount >= 100),
      upi_id TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Pending'
        CHECK(status IN ('Pending','Approved','Paid','Rejected')),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE INDEX IF NOT EXISTS idx_transactions_user_created
      ON transactions(user_id, created_at DESC);

    CREATE INDEX IF NOT EXISTS idx_withdrawals_user_created
      ON withdrawals(user_id, created_at DESC);
  `);
  console.log("VINU JS V18 DB READY");
}

async function getOrCreateUser(client, userId) {
  await client.query(
    `INSERT INTO users(id) VALUES($1) ON CONFLICT(id) DO NOTHING`,
    [userId]
  );
}

function validUserId(v) {
  return typeof v === "string" && /^[A-Za-z0-9_-]{3,80}$/.test(v);
}

function validUpi(v) {
  return typeof v === "string" &&
    v.length >= 3 && v.length <= 120 &&
    /^[A-Za-z0-9._-]+@[A-Za-z0-9.-]+$/.test(v);
}

async function fetchAdmobKeys() {
  if (Date.now() - keyCache.fetchedAt < 23 * 60 * 60 * 1000 && keyCache.keys.size) {
    return keyCache.keys;
  }

  const r = await fetch(ADMOB_KEYS_URL);
  if (!r.ok) throw new Error("AdMob key server HTTP " + r.status);
  const data = await r.json();
  const map = new Map();

  for (const k of (data.keys || [])) {
    if (k.keyId && k.pem) map.set(String(k.keyId), k.pem);
  }
  if (!map.size) throw new Error("No AdMob public keys received");

  keyCache = { keys: map, fetchedAt: Date.now() };
  return map;
}

async function verifyAdMobSSV(req) {
  const q = req.originalUrl.split("?")[1] || "";
  const sigMarker = q.indexOf("&signature=");
  const sigMarkerStart = sigMarker >= 0 ? sigMarker : q.indexOf("signature=");

  if (sigMarkerStart < 0) throw new Error("Missing signature");
  const signedContent = q.slice(0, sigMarkerStart);
  const tail = q.slice(sigMarkerStart + 1);

  const tailParts = tail.split("&");
  const sigPart = tailParts.find(x => x.startsWith("signature="));
  const keyPart = tailParts.find(x => x.startsWith("key_id="));
  if (!sigPart || !keyPart) throw new Error("Missing signature/key_id");

  const signatureB64 = decodeURIComponent(sigPart.slice("signature=".length));
  const keyId = decodeURIComponent(keyPart.slice("key_id=".length));
  const keys = await fetchAdmobKeys();
  const pem = keys.get(String(keyId));
  if (!pem) throw new Error("Unknown AdMob key_id");

  const signature = Buffer.from(signatureB64, "base64");
  const ok = crypto.verify(
    "sha256",
    Buffer.from(signedContent, "utf8"),
    { key: pem, dsaEncoding: "der" },
    signature
  );
  if (!ok) throw new Error("Invalid AdMob SSV signature");

  const params = new URLSearchParams(signedContent);
  return {
    ad_network: params.get("ad_network") || "",
    ad_unit: params.get("ad_unit") || "",
    reward_amount: Number(params.get("reward_amount") || 0),
    reward_item: params.get("reward_item") || "",
    timestamp: Number(params.get("timestamp") || 0),
    transaction_id: params.get("transaction_id") || "",
    user_id: params.get("user_id") || "",
    custom_data: params.get("custom_data") || ""
  };
}

app.get("/", (req, res) => res.json({
  ok: true,
  service: "VINU JS V18 secure earning backend",
  ssv: "/api/admob/ssv"
}));

app.get("/api/health", async (req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ ok: true, database: "connected" });
  } catch (e) {
    res.status(503).json({ ok: false, database: "error" });
  }
});

app.get("/api/wallet/:userId", async (req, res) => {
  const { userId } = req.params;
  if (!validUserId(userId)) return res.status(400).json({ error: "Invalid userId" });

  try {
    await getOrCreateUser(pool, userId);
    const r = await pool.query(
      `SELECT id,balance,total_earned,created_at,updated_at FROM users WHERE id=$1`,
      [userId]
    );
    res.json(r.rows[0]);
  } catch (e) {
    res.status(500).json({ error: "Wallet unavailable" });
  }
});

app.get("/api/history/:userId", async (req, res) => {
  const { userId } = req.params;
  if (!validUserId(userId)) return res.status(400).json({ error: "Invalid userId" });
  try {
    const r = await pool.query(
      `SELECT id,amount,type,description,reference_id,created_at
       FROM transactions WHERE user_id=$1
       ORDER BY created_at DESC LIMIT 100`,
      [userId]
    );
    res.json(r.rows);
  } catch {
    res.status(500).json({ error: "History unavailable" });
  }
});

app.get("/api/withdrawals/:userId", async (req, res) => {
  const { userId } = req.params;
  if (!validUserId(userId)) return res.status(400).json({ error: "Invalid userId" });
  try {
    const r = await pool.query(
      `SELECT id,amount,upi_id,status,created_at,updated_at
       FROM withdrawals WHERE user_id=$1
       ORDER BY created_at DESC LIMIT 100`,
      [userId]
    );
    res.json(r.rows);
  } catch {
    res.status(500).json({ error: "Withdrawals unavailable" });
  }
});

/*
  SECURITY:
  There is intentionally NO public endpoint that accepts {reward: X}
  and credits the wallet. Reward credit happens only after verified
  AdMob SSV.
*/
app.get("/api/admob/ssv", async (req, res) => {
  try {
    const s = await verifyAdMobSSV(req);

    if (!s.transaction_id || !s.user_id || !s.reward_amount) {
      return res.status(400).send("invalid");
    }

    if (s.timestamp && Math.abs(Date.now() - s.timestamp) > SSV_MAX_AGE_MS) {
      return res.status(400).send("stale");
    }

    if (ADMOB_SSV_AD_UNIT && s.ad_unit !== ADMOB_SSV_AD_UNIT) {
      return res.status(400).send("wrong_ad_unit");
    }

    const custom = s.custom_data ? JSON.parse(decodeURIComponent(s.custom_data)) : {};
    const userId = s.user_id || custom.userId;

    if (!validUserId(userId)) return res.status(400).send("invalid_user");

    const reward = Math.floor(s.reward_amount);
    if (reward <= 0 || reward > 1000) return res.status(400).send("invalid_reward");

    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      await getOrCreateUser(client, userId);

      const inserted = await client.query(
        `INSERT INTO ad_rewards(transaction_id,user_id,reward_amount,reward_item,ad_unit,ad_network)
         VALUES($1,$2,$3,$4,$5,$6)
         ON CONFLICT(transaction_id) DO NOTHING
         RETURNING transaction_id`,
        [s.transaction_id, userId, reward, s.reward_item, s.ad_unit, s.ad_network]
      );

      if (!inserted.rowCount) {
        await client.query("COMMIT");
        return res.status(200).send("duplicate");
      }

      await client.query(
        `UPDATE users
         SET balance=balance+$1,total_earned=total_earned+$1,updated_at=NOW()
         WHERE id=$2`,
        [reward, userId]
      );

      await client.query(
        `INSERT INTO transactions(user_id,amount,type,description,reference_id)
         VALUES($1,$2,'ad_reward',$3,$4)`,
        [userId, reward, `Verified AdMob reward: ${reward}`, s.transaction_id]
      );

      await client.query("COMMIT");
      return res.status(200).send("ok");
    } catch (e) {
      await client.query("ROLLBACK");
      throw e;
    } finally {
      client.release();
    }
  } catch (e) {
    console.error("SSV:", e.message);
    return res.status(400).send("invalid");
  }
});

app.post("/api/withdraw", async (req, res) => {
  const { userId, amount, upiId } = req.body || {};
  const amt = Number(amount);

  if (!validUserId(userId)) return res.status(400).json({ success:false, message:"Invalid user" });
  if (!Number.isInteger(amt) || amt < MIN_WITHDRAWAL) {
    return res.status(400).json({ success:false, message:`Minimum ₹${MIN_WITHDRAWAL}` });
  }
  if (!validUpi(upiId)) {
    return res.status(400).json({ success:false, message:"Valid UPI ID daalo" });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await getOrCreateUser(client, userId);

    const u = await client.query(
      `SELECT balance FROM users WHERE id=$1 FOR UPDATE`,
      [userId]
    );

    if (!u.rows.length || u.rows[0].balance < amt) {
      await client.query("ROLLBACK");
      return res.status(400).json({ success:false, message:"Balance kam hai" });
    }

    const w = await client.query(
      `INSERT INTO withdrawals(user_id,amount,upi_id,status)
       VALUES($1,$2,$3,'Pending') RETURNING id,amount,upi_id,status,created_at`,
      [userId, amt, upiId]
    );

    await client.query(
      `UPDATE users SET balance=balance-$1,updated_at=NOW() WHERE id=$2`,
      [amt, userId]
    );

    await client.query(
      `INSERT INTO transactions(user_id,amount,type,description,reference_id)
       VALUES($1,$2,'withdrawal',$3,$4)`,
      [userId, -amt, `Withdrawal request ₹${amt}`, String(w.rows[0].id)]
    );

    const wallet = await client.query(
      `SELECT balance,total_earned FROM users WHERE id=$1`,
      [userId]
    );

    await client.query("COMMIT");
    res.json({
      success:true,
      message:"Withdrawal request Pending. Admin approval ke baad payout hoga.",
      withdrawal:w.rows[0],
      balance:wallet.rows[0].balance
    });
  } catch (e) {
    await client.query("ROLLBACK");
    res.status(500).json({ success:false, message:"Withdrawal failed" });
  } finally {
    client.release();
  }
});

db().then(() => {
  app.listen(PORT, () => console.log(`VINU JS backend running on ${PORT}`));
}).catch(e => {
  console.error("DB init failed:", e);
  process.exit(1);
});
